import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
from torchvision import transforms, datasets
from tqdm import tqdm
import os
import time
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import timm

# 한글 폰트 설정
plt.rcParams['font.family'] = 'DejaVu Sans'
plt.rcParams['axes.unicode_minus'] = False

# timm의 Block 클래스를 확장하여 어텐션 가중치를 반환하도록 수정
def patch_forward_block(self, x, return_attention=False, attn_mask=None):
    if not return_attention:
        return self._original_forward(x, attn_mask=attn_mask)
    
    x = self.norm1(x)
    attn_output, attn_weights = self.attn(x, return_attention=True, attn_mask=attn_mask)
    
    # drop_path가 없는 경우 처리
    if hasattr(self, 'drop_path'):
        x = x + self.drop_path(attn_output)
        x = x + self.drop_path(self.mlp(self.norm2(x)))
    else:
        x = x + attn_output
        x = x + self.mlp(self.norm2(x))
        
    return x, attn_weights

# timm의 Attention 클래스를 확장하여 어텐션 가중치를 반환하도록 수정
def patch_forward_attention(self, x, return_attention=False, attn_mask=None):
    if not return_attention:
        return self._original_forward(x, attn_mask=attn_mask)
    
    B, N, C = x.shape
    qkv = self.qkv(x).reshape(B, N, 3, self.num_heads, C // self.num_heads).permute(2, 0, 3, 1, 4)
    q, k, v = qkv[0], qkv[1], qkv[2]
    
    attn = (q @ k.transpose(-2, -1)) * self.scale
    attn = attn.softmax(dim=-1)
    attn_weights = attn  # 어텐션 가중치 저장
    attn = self.attn_drop(attn)
    
    x = (attn @ v).transpose(1, 2).reshape(B, N, C)
    x = self.proj(x)
    x = self.proj_drop(x)
    
    if return_attention:
        return x, attn_weights
    else:
        return x

# 모델 로드 전에 timm 라이브러리의 Block과 Attention 클래스 패치
def patch_timm_for_attention():
    from timm.models.vision_transformer import Block, Attention
    
    # 원본 forward 메소드 저장 (이미 저장되어 있지 않은 경우에만)
    if not hasattr(Block, '_original_forward'):
        Block._original_forward = Block.forward
    if not hasattr(Attention, '_original_forward'):
        Attention._original_forward = Attention.forward
    
    # 새로운 forward 메소드로 교체
    Block.forward = patch_forward_block
    Attention.forward = patch_forward_attention

class ViTClassifier(nn.Module):
    def __init__(self, num_classes=3, pretrained=True, freeze_backbone=False, 
                img_size=224, patch_size=16, embed_dim=768, depth=12, 
                num_heads=12, mlp_ratio=4.0, top_k=8, local_tokens=4, drop_rate=0.1):
        super(ViTClassifier, self).__init__()

        # 모델 파라미터 저장
        self.img_size = img_size
        self.patch_size = patch_size
        self.num_patches = (img_size // patch_size) ** 2
        self.top_k = top_k

        # pretrained ViT 모델 불러오기 (base 크기 사용)
        # 기본 구성이 있는 파라미터들은 제거하고 필요한 것만 전달
        self.vit = timm.create_model(
            'vit_base_patch16_224', 
            pretrained=pretrained,
            img_size=img_size,
            drop_rate=drop_rate,
            num_classes=num_classes  # 클래스 수만 변경
        )

        # backbone (특징 추출기) 동결 여부 결정
        if freeze_backbone:
            for param in self.vit.parameters():
                param.requires_grad = False

        # 분류기 부분 변경
        self.vit.head = nn.Linear(self.vit.head.in_features, num_classes)
        
        # 어텐션맵 시각화를 위한 속성들
        self.cls_token = self.vit.cls_token
        self.pos_embed = self.vit.pos_embed
        self.pos_drop = self.vit.pos_drop
        self.blocks = self.vit.blocks
        self.norm = self.vit.norm
        self.patch_embed = self.vit.patch_embed

    def forward(self, x, return_last_attn=False):
        if not return_last_attn:
            return self.vit(x)
        else:
            # 어텐션맵 추출을 위한 forward 구현
            B = x.shape[0]
            x = self.patch_embed(x)
            
            cls_tokens = self.cls_token.expand(B, -1, -1)
            x = torch.cat((cls_tokens, x), dim=1)
            x = x + self.pos_embed
            x = self.pos_drop(x)
            
            attn_weights = None
            for i, blk in enumerate(self.blocks):
                if i == len(self.blocks) - 1:  # 마지막 블록의 어텐션 가중치 저장
                    x, attn_weights = blk(x, return_attention=True)
                else:
                    x = blk(x)
                    
            x = self.norm(x)
            x_cls = x[:, 0]
            logits = self.vit.head(x_cls)
            
            return logits, x_cls, x, attn_weights
    
    def compute_patch_importance(self, patch_embeddings):
        """패치 중요도 계산"""
        # 패치 임베딩의 L2 노름을 계산하여 중요도 측정
        return torch.norm(patch_embeddings, dim=2)
        
def get_transforms(img_size=224):
    transform_train = transforms.Compose([
        transforms.Resize((256, 256)),
        transforms.RandomCrop(img_size),
        transforms.RandomHorizontalFlip(p=0.5),
        transforms.RandomRotation(15),
        transforms.ColorJitter(brightness=0.2, contrast=0.2, saturation=0.2),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])
    ])

    transform_val = transforms.Compose([
        transforms.Resize((img_size, img_size)),
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                             std=[0.229, 0.224, 0.225])
    ])

    return transform_train, transform_val

# 3번 반복 실험을 위한 함수
def run_single_experiment(experiment_id, device, train_loader, val_loader, results_dir):
    """단일 실험 실행"""
    print(f"\n=== 실험 {experiment_id + 1}/3 시작 ===")
    
    # timm 패치 적용 (한 번만)
    if experiment_id == 0:
        patch_timm_for_attention()
    
    # 모델 초기화 (매번 새로운 모델)
    model = ViTClassifier(num_classes=3, pretrained=True, freeze_backbone=False)
    model = model.to(device)
    
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.AdamW(model.parameters(), lr=5e-5, weight_decay=0.01)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=20, eta_min=1e-6)
    
    # 실험별 결과 저장
    epochs = []
    train_accs = []
    val_accs = []
    train_losses = []
    val_losses = []
    epoch_times = []
    total_times = []
    
    train_epoch = 30
    total_start_time = time.time()
    best_val_acc = 0.0
    
    for epoch in range(train_epoch):
        # 에포크 시작 시간 측정
        epoch_start_time = time.time()
        model.train()
        running_loss = 0.0
        correct = 0
        total = 0

        pbar = tqdm(train_loader, desc=f"Epoch {epoch+1}/30")
        for inputs, labels in pbar:
            inputs, labels = inputs.to(device), labels.to(device)

            optimizer.zero_grad()
            outputs = model(inputs)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item() * inputs.size(0)
            _, predicted = outputs.max(1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()

            pbar.set_postfix(loss=f"{running_loss/total:.4f}", acc=f"{100.*correct/total:.2f}%")
        
        # 훈련 정확도와 손실 기록
        train_loss = running_loss / total  # 에폭별 평균 훈련 손실
        train_acc = 100. * correct / total
        train_accs.append(train_acc)
        train_losses.append(train_loss)  # 손실 저장

        scheduler.step()

        val_loss = 0.0
        val_correct = 0
        val_total = 0
        model.eval()
        with torch.no_grad():
            for inputs, labels in val_loader:
                inputs, labels = inputs.to(device), labels.to(device)
                outputs = model(inputs)
                loss = criterion(outputs, labels)

                val_loss += loss.item() * inputs.size(0)
                _, predicted = outputs.max(1)
                val_total += labels.size(0)
                val_correct += predicted.eq(labels).sum().item()

        # 에포크 시간 계산
        epoch_time = time.time() - epoch_start_time
        total_time = time.time() - total_start_time
        
        # 검증 정확도와 손실 기록
        val_avg_loss = val_loss / val_total  # 에폭별 평균 검증 손실
        val_acc = 100. * val_correct / val_total
        val_accs.append(val_acc)
        val_losses.append(val_avg_loss)  # 손실 저장
        epochs.append(epoch + 1)
        epoch_times.append(epoch_time)  # 에포크 시간 기록
        total_times.append(total_time)  # 누적 총 시간 기록
        
        print(f'Epoch {epoch+1}, Train Loss: {train_loss:.4f}, Train Acc: {train_acc:.2f}%, Val Loss: {val_avg_loss:.4f}, Val Acc: {val_acc:.2f}%, Epoch Time: {epoch_time:.2f}s, Total Time: {total_time:.2f}s')
    
    # 실험 결과 반환
    return {
        'epochs': epochs,
        'train_accs': train_accs,
        'val_accs': val_accs,
        'train_losses': train_losses,
        'val_losses': val_losses,
        'epoch_times': epoch_times,
        'total_times': total_times
    }

def calculate_std_deviation(experiments_data):
    """실험 결과들의 표준편차 계산"""
    num_experiments = len(experiments_data)
    num_epochs = len(experiments_data[0]['train_accs'])
    
    # 각 에포크별로 표준편차 계산
    train_acc_std = []
    val_acc_std = []
    train_loss_std = []
    val_loss_std = []
    
    for epoch_idx in range(num_epochs):
        # 해당 에포크의 모든 실험 결과 수집
        epoch_train_accs = [exp['train_accs'][epoch_idx] for exp in experiments_data]
        epoch_val_accs = [exp['val_accs'][epoch_idx] for exp in experiments_data]
        epoch_train_losses = [exp['train_losses'][epoch_idx] for exp in experiments_data]
        epoch_val_losses = [exp['val_losses'][epoch_idx] for exp in experiments_data]
        
        # 표준편차 계산
        train_acc_std.append(np.std(epoch_train_accs))
        val_acc_std.append(np.std(epoch_val_accs))
        train_loss_std.append(np.std(epoch_train_losses))
        val_loss_std.append(np.std(epoch_val_losses))
    
    return train_acc_std, val_acc_std, train_loss_std, val_loss_std

# 사용 예시
if __name__ == "__main__":
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # 데이터 로더 설정
    transform_train, transform_val = get_transforms(224)
    train_dataset = datasets.ImageFolder('/home/storage1/hyein/trans_FG/dataset_cls_PE_aug/train', transform=transform_train)
    val_dataset = datasets.ImageFolder('/home/storage1/hyein/trans_FG/dataset_cls_PE_aug/val', transform=transform_val)
    train_loader = DataLoader(train_dataset, batch_size=16, shuffle=True, num_workers=4)
    val_loader = DataLoader(val_dataset, batch_size=16, shuffle=False, num_workers=4)
    
    # 결과 저장 경로 생성
    results_dir = '/home/storage1/hyein/trans_FG/model/model/ViT/results'
    os.makedirs(results_dir, exist_ok=True)
    
    # 3번 반복 실험 실행
    experiments_data = []
    for exp_id in range(3):
        # 각 실험마다 다른 random seed 설정
        torch.manual_seed(42 + exp_id)
        np.random.seed(42 + exp_id)
        
        experiment_result = run_single_experiment(exp_id, device, train_loader, val_loader, results_dir)
        experiments_data.append(experiment_result)
    
    # 표준편차 계산
    train_acc_std, val_acc_std, train_loss_std, val_loss_std = calculate_std_deviation(experiments_data)
    
    # 평균 결과 계산 (첫 번째 실험 결과 사용)
    epochs = experiments_data[0]['epochs']
    train_accs = experiments_data[0]['train_accs']
    val_accs = experiments_data[0]['val_accs']
    train_losses = experiments_data[0]['train_losses']
    val_losses = experiments_data[0]['val_losses']
    epoch_times = experiments_data[0]['epoch_times']
    total_times = experiments_data[0]['total_times']

    # 학습 결과 시각화 - 정확도 그래프 (실제 표준편차 사용)
    plt.figure(figsize=(10, 6))
    plt.errorbar(epochs, train_accs, yerr=train_acc_std, fmt='b-o', 
                label='훈련 정확도', capsize=3, capthick=1)
    plt.errorbar(epochs, val_accs, yerr=val_acc_std, fmt='r-o', 
                label='검증 정확도', capsize=3, capthick=1)
    plt.title('에포크별 정확도 (실제 표준편차 Error Bar)')
    plt.xlabel('에포크')
    plt.ylabel('정확도 (%)')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()

    # 그래프 저장
    plt.savefig(os.path.join(results_dir, 'accuracy_results.png'), dpi=300)
    plt.show()

    # 학습 결과 시각화 - 손실 그래프 (실제 표준편차 사용)
    plt.figure(figsize=(10, 6))
    plt.errorbar(epochs, train_losses, yerr=train_loss_std, fmt='b-o', 
                label='훈련 손실', capsize=3, capthick=1)
    plt.errorbar(epochs, val_losses, yerr=val_loss_std, fmt='r-o', 
                label='검증 손실', capsize=3, capthick=1)
    plt.title('에포크별 손실 (실제 표준편차 Error Bar)')
    plt.xlabel('에포크')
    plt.ylabel('손실')
    plt.legend()
    plt.grid(True)
    plt.tight_layout()

    # 손실 그래프 저장
    plt.savefig(os.path.join(results_dir, 'loss_results.png'), dpi=300)
    plt.show()

    # 총 학습 시간 출력 (첫 번째 실험의 시간 사용)
    total_training_time = experiments_data[0]['total_times'][-1]  # 마지막 에포크의 총 시간
    print(f"\n총 학습 시간: {total_training_time:.2f}초 ({total_training_time/60:.2f}분)")
    print(f"평균 에포크 시간: {total_training_time/30:.2f}초")

    # Origin 프로그램용 CSV 파일로 결과 저장 (실제 표준편차 포함)
    results_df = pd.DataFrame({
        'Epoch': epochs,
        'Train_Accuracy': train_accs,
        'Val_Accuracy': val_accs,
        'Train_Loss': train_losses,
        'Val_Loss': val_losses,
        'Epoch_Time': epoch_times,
        'Total_Time': total_times,
        'Train_Acc_ErrorBar': train_acc_std,  # 실제 표준편차
        'Val_Acc_ErrorBar': val_acc_std,      # 실제 표준편차
        'Train_Loss_ErrorBar': train_loss_std, # 실제 표준편차
        'Val_Loss_ErrorBar': val_loss_std     # 실제 표준편차
    })

    csv_path = os.path.join(results_dir, 'training_results.csv')
    results_df.to_csv(csv_path, index=False)
    print(f'학습 결과(정확도와 손실)가 Origin 프로그램용 CSV 파일로 저장되었습니다: {csv_path}')
    print(f'실제 표준편차가 계산되어 Error Bar에 사용되었습니다.')